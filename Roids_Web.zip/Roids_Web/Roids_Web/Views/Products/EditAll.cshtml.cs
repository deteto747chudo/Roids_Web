using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Roids_Web.Views.Products
{
    public class EditAllModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
