using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Roids_Web.Views.FAQs
{
    public class EditAllModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
